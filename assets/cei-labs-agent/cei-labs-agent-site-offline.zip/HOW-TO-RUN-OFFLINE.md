# Running this site fully offline

This is a snapshot of the CEI Labs info site (normally at
`cei-labs.cyberexperts.org`), bundled so it works with **zero internet
connection** — useful on spotty venue Wi-Fi.

The pages link to each other with root-relative paths (like `/agent/`), so
opening `index.html` directly by double-clicking it won't navigate
correctly. Serve the folder instead — every OS listed below already has
what you need, no install required:

## Windows

Open the folder in File Explorer, click the address bar, type `powershell`,
press Enter, then run:

```powershell
python -m http.server 8080
```

## macOS / Linux

Open a terminal in this folder and run:

```sh
python3 -m http.server 8080
```

Then open **http://localhost:8080/** in your browser. Press Ctrl+C in the
terminal to stop the server when you're done.

If `python`/`python3` isn't available, any other static file server works
identically (e.g. `npx serve .` if you have Node.js).
